public class Data{
	int dia,mes,ano;
	public Data(int d, int m, int a){
		this.dia = d;
		this.mes = m;
		this.ano = a;
	}
	public String formatada(){
		return String.format("%02d/%02d/%02d",this.dia,this.mes,this.ano);		
	}

}
