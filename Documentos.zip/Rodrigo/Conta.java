import java.util.Scanner;

class Conta{
	private int 	numero;
	private String 	dono;
	private double 	saldo;

	Scanner entrada = new Scanner (System.in);

	boolean	saca(double valor){
		if (this.saldo >= valor){
			this.saldo -= valor;
			return true;
			
		}else{
			return false;
		}

		
	}
	public void	deposita(double valor){
		this.saldo += valor;
	}
	public void	criar(){
			Conta minhaConta = new Conta();
			System.out.println("\n\n Informe o numero da conta: ");		
			minhaConta.dono = entrada.nextLine();	
			System.out.println("\n\n Informe o Titular da conta: ");
	}
	public void transferePara(Conta contaOrigem, Conta contaDestino, double valor){
	//		if ((valor > 0) and contaOrigem.saldo 
	//		contaOrigem.saca(valor);
	//		contaDestino.deposita(valor);
	}
}
