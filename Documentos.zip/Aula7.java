import javax.swing.JOptionPane;

public class Aula7{
	public static void main(String[] args){
	JOptionPane.showMessageDialog(null, "É Java \nMano!");
	}
}
