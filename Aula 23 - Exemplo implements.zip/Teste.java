
public class Teste {
	public static void main(String[] args){
		
		Retangulo r1 = new Retangulo(10,2);
		r1.calculaArea();
		System.out.println("Area: " + r1.calculaArea());
		
		Quadrado q1 = new Quadrado(10);
		q1.calculaArea();
		System.out.println("Area: " + q1.calculaArea());
		
		Circulo c1 = new Circulo(10);
		c1.calculaArea();
		System.out.println("Area: " + c1.calculaArea());		
	}
}
