
class Retangulo implements AreaCalculavel{
	double area;
	double lado;
	double altura;
	
	public Retangulo(double l, double h){
		this.lado = l;
		this.altura = h;		
	}
	
	public double calculaArea(){
		return this.lado * this.altura;
	}
}
