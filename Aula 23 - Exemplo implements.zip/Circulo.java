

class Circulo implements AreaCalculavel{
	double raio;
	public Circulo(double r){
		this.raio = r;
	}
	public double calculaArea(){
		return Math.PI * Math.pow(this.raio,2);
	}
}
