class teste{
    public static void main(String[] args){
        EmpregadoDaFaculdade p1 = new EmpregadoDaFaculdade();
        p1.setNome("Rodrigo");
        p1.setSalario(1000);

        ProfessorDaFaculdade p2 = new ProfessorDaFaculdade();
        p2.setNome("Felipe");
        p2.setSalario(1000);
        p2.sethorasDeAula(4);

        GeradorDeRelatorio relatorio = new GeradorDeRelatorio();
        relatorio.add(p1);
        relatorio.add(p2);
    }
}
