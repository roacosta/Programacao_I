class ProfessorDaFaculdade extends EmpregadoDaFaculdade
{
    private int horasDeAula;

    public void sethorasDeAula(int horasParm){
        this.horasDeAula = horasParm;
    }

    @Override
    double getGastos(){
        return (this.getSalario() + (10 * this.horasDeAula));
    }
    // métodos de get, set e outros
    // sobrescreva os métodos
}
