class EmpregadoDaFaculdade{
    private String nome;
    private double salario;

    double getGastos(){
        return this.salario;
    }

    String getInfo(){
        return "nome: " + this.nome + " com salário " + this.salario;
    }

    void setSalario(double salarioParm){
        this.salario = salarioParm;
    }

    double getSalario(){
        return this.salario;
    }

    void setNome(String nomeParm){
        this.nome = nomeParm;
    }
    // métodos de get, set e outros
}

