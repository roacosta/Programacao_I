class GeradorDeRelatorio{
    public void add(EmpregadoDaFaculdade Empregado){
        System.out.println(Empregado.getGastos());
    }
}
